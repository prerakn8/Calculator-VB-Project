﻿Public Class Form1
    'Prerak Naik
    'Period 6
    '3/18/1024
    'DO NOT CHANGE!
    Dim ans
    Dim oldnum As Decimal
    Dim newnum As Decimal
    Dim operation As String
    Dim hasbeencleared As Boolean = True
    Dim testnum As Decimal
    Dim errornum As Integer = 0
    Dim mode As String = "exp"

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox1.Text += "1"
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text += "2"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox1.Text += "3"
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        TextBox1.Text += "4"
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        TextBox1.Text += "5"
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBox1.Text += "6"
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        TextBox1.Text += "7"
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        TextBox1.Text += "8"
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        TextBox1.Text += "9"
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        TextBox1.Text += "0"
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        TextBox1.Text += "."
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        TextBox1.Text += Str(Math.PI)
    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        If hasbeencleared = True Then
            newnum = TextBox1.Text
        Else
            newnum = newnum
        End If
        If operation = "+" Then
            oldnum += newnum
            ans = oldnum
            TextBox1.Text = Str(ans)
        ElseIf operation = "-" Then
            oldnum -= newnum
            ans = oldnum
            TextBox1.Text = Str(ans)
        ElseIf operation = "x" Then
            oldnum *= newnum
            ans = oldnum
            TextBox1.Text = Str(ans)
        ElseIf operation = "/" Then
            If newnum = 0 Then
                If errornum < 3 Then
                    My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                    MsgBox("You cannot divide by a 0. Sorry!", MsgBoxStyle.Critical, "Math Error")
                    errornum += 1
                ElseIf errornum = 3 Then
                    My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                    MsgBox("Okay. Seriously. Stop.", MsgBoxStyle.Critical, "Math Error")
                    errornum = 0
                End If
            Else
                oldnum /= newnum
                ans = oldnum
                TextBox1.Text = Str(ans)
            End If
        End If
        hasbeencleared = False

    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.Length - 1)
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        If TextBox1.Text = "" Then
            If errornum < 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Cannot perform operation before number!", MsgBoxStyle.Critical, "Math Error")
                errornum += 1
                TextBox1.Text = ""
            ElseIf errornum = 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Okay. Seriously. Stop.", MsgBoxStyle.Critical, "Math Error")
                errornum = 0
                TextBox1.Text = ""
            End If
        Else
            oldnum = TextBox1.Text
            operation = "+"
            TextBox1.Text = ""
            hasbeencleared = True
        End If
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        If TextBox1.Text = "" Then
            TextBox1.Text = "-"
            oldnum = "-0"
            operation = "-"
            hasbeencleared = True
        Else
            oldnum = TextBox1.Text
            operation = "-"
            TextBox1.Text = ""
            hasbeencleared = True
        End If
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        If TextBox1.Text = "" Then
            If errornum < 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Cannot perform operation before number!", MsgBoxStyle.Critical, "Math Error")
                errornum += 1
                TextBox1.Text = ""
            ElseIf errornum = 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Okay. Seriously. Stop.", MsgBoxStyle.Critical, "Math Error")
                errornum = 0
                TextBox1.Text = ""
            End If
        Else
            oldnum = TextBox1.Text
            operation = "/"
            TextBox1.Text = ""
            hasbeencleared = True
        End If
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        If TextBox1.Text = "" Then
            If errornum < 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Cannot perform operation before number!", MsgBoxStyle.Critical, "Math Error")
                errornum += 1
                TextBox1.Text = ""
            ElseIf errornum = 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Okay. Seriously. Stop.", MsgBoxStyle.Critical, "Math Error")
                errornum = 0
                TextBox1.Text = ""
            End If
        Else
            oldnum = TextBox1.Text
            operation = "x"
            TextBox1.Text = ""
            hasbeencleared = True
        End If
    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        oldnum = 0
        operation = ""
        TextBox1.Text = ""
        ans = 0
        hasbeencleared = True
    End Sub
    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        Panel2.Visible = Not Panel2.Visible
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        TextBox1.Text = Str(Int(TextBox1.Text) ^ 2)
    End Sub

    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        If TextBox1.Text.Contains("-") Then
            If errornum < 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Sorry, we have not added imaginary numbers yet!", MsgBoxStyle.Critical, "Math Error")
                errornum += 1
                TextBox1.Text = oldnum
            ElseIf errornum = 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Okay. Seriously. Stop.", MsgBoxStyle.Critical, "Math Error")
                errornum = 0
                TextBox1.Text = oldnum
            End If
        ElseIf TextBox1.Text = "" Then
            If errornum < 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Please enter a number", MsgBoxStyle.Critical, "Math Error")
                errornum += 1
                TextBox1.Text = oldnum
            ElseIf errornum = 3 Then
                My.Computer.Audio.Play("D:\clprj1\Untitled video - Made with Clipchamp (6) (audio-extractor.net).wav")
                MsgBox("Okay. Seriously. Stop.", MsgBoxStyle.Critical, "Math Error")
                errornum = 0
                TextBox1.Text = oldnum
            End If
        Else
            TextBox1.Text = Str(Int(TextBox1.Text) ^ 0.5)
        End If
    End Sub
End Class
